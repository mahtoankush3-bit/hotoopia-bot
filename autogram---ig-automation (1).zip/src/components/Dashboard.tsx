import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  MessageCircle, 
  Instagram, 
  Activity, 
  Link2, 
  FileText, 
  CheckCircle2,
  Plus,
  MessageSquare,
  Hash,
  Filter,
  ToggleRight,
  ToggleLeft,
  X,
  Image as ImageIcon,
  PlayCircle,
  LayoutDashboard,
  MessageSquare as AllDmsIcon,
  Video as LiveIcon,
  AtSign as MentionIcon,
  Settings,
  Menu,
  LogOut
} from 'lucide-react';

interface DashboardProps {
  onBack: () => void;
}

export default function Dashboard({ onBack }: DashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isAddingRule, setIsAddingRule] = useState(false);
  const [triggerType, setTriggerType] = useState('all');
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [igPosts, setIgPosts] = useState<any[]>([]);
  const [loadingPosts, setLoadingPosts] = useState(false);

  React.useEffect(() => {
    if (triggerType === 'specific' && igPosts.length === 0) {
      setLoadingPosts(true);
      fetch('/api/instagram/posts')
        .then(res => res.json())
        .then(data => {
          if (data.posts) {
            setIgPosts(data.posts);
          }
        })
        .catch(err => console.error(err))
        .finally(() => setLoadingPosts(false));
    }
  }, [triggerType]);

  const [rules, setRules] = useState([
    { id: 1, keyword: 'Notes', trigger: 'All Posts', response: 'Here are your Class 10 Notes: [Link]', active: true },
    { id: 2, keyword: 'Group', trigger: 'Specific Reel', response: 'Join our community group: [Link]', active: true }
  ]);

  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'dm_comments', label: 'DM from Comments', icon: MessageCircle },
    { id: 'dm_stories', label: 'DM from Stories', icon: PlayCircle },
    { id: 'dm_all', label: 'Respond to all DMs', icon: AllDmsIcon },
    { id: 'dm_live', label: 'Live Comments', icon: LiveIcon },
    { id: 'dm_mentions', label: 'Story Mentions', icon: MentionIcon },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-8">
            {/* Welcome Banner */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-indigo-600/10 border border-indigo-500/30 p-8 md:p-10 relative overflow-hidden flex flex-col justify-center"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/20 blur-3xl rounded-full -translate-y-1/2 translate-x-1/3"></div>
              <h1 className="text-2xl md:text-3xl font-black uppercase tracking-tighter mb-3 relative z-10">Welcome back to Hotoopia Analytics!</h1>
              <p className="text-indigo-200/70 text-sm font-medium relative z-10 max-w-xl">
                Your direct message automation system is running smoothly. Monitor student interactions and manage your trigger rules.
              </p>
            </motion.div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-white/5 border border-white/10 p-6 flex flex-col justify-between h-36 relative overflow-hidden group hover:border-indigo-500/50 transition-colors"
              >
                <div className="flex items-center justify-between text-gray-400 mb-4">
                  <span className="text-[10px] font-bold uppercase tracking-widest">Total Replies Sent</span>
                  <MessageCircle className="w-5 h-5 text-indigo-400" />
                </div>
                <div className="text-4xl font-black tracking-tighter">1,240</div>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white/5 border border-white/10 p-6 flex flex-col justify-between h-36 relative overflow-hidden group hover:border-indigo-500/50 transition-colors"
              >
                <div className="flex items-center justify-between text-gray-400 mb-4">
                  <span className="text-[10px] font-bold uppercase tracking-widest">Active Handle</span>
                  <Instagram className="w-5 h-5 text-pink-400" />
                </div>
                <div className="text-2xl font-bold tracking-tight text-white/90">@hotoopia.hs</div>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-white/5 border border-white/10 p-6 flex flex-col justify-between h-36 relative overflow-hidden group hover:border-indigo-500/50 transition-colors"
              >
                 <div className="flex items-center justify-between text-gray-400 mb-4">
                  <span className="text-[10px] font-bold uppercase tracking-widest">System Status</span>
                  <Activity className="w-5 h-5 text-green-400" />
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.6)]"></div>
                  <span className="text-sm font-bold uppercase tracking-widest text-green-400">Live & Monitoring DMs</span>
                </div>
              </motion.div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Quick Settings */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="lg:col-span-1 bg-[#050505] border border-white/10 p-6"
              >
                <h3 className="text-sm font-bold uppercase tracking-widest mb-6 pb-4 border-b border-white/10 flex items-center gap-2">
                  Quick Settings
                </h3>
                
                <div className="space-y-6">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2 flex items-center gap-2">
                      <Link2 className="w-3 h-3" /> WhatsApp Group Link
                    </label>
                    <input 
                      type="text" 
                      defaultValue="https://chat.whatsapp.com/Gry..."
                      className="w-full bg-white/5 border border-white/10 px-4 py-3 text-xs font-mono focus:outline-none focus:border-indigo-500 transition-colors text-white border-dashed"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2 flex items-center gap-2">
                      <FileText className="w-3 h-3" /> Class 10 PDF Path
                    </label>
                    <input 
                      type="text" 
                      defaultValue="drive.google.com/folder/class10"
                      className="w-full bg-white/5 border border-white/10 px-4 py-3 text-xs font-mono focus:outline-none focus:border-indigo-500 transition-colors text-white border-dashed"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2 flex items-center gap-2">
                      <FileText className="w-3 h-3" /> Class 12 PDF Path
                    </label>
                    <input 
                      type="text" 
                      defaultValue="drive.google.com/folder/class12"
                      className="w-full bg-white/5 border border-white/10 px-4 py-3 text-xs font-mono focus:outline-none focus:border-indigo-500 transition-colors text-white border-dashed"
                    />
                  </div>
      
                  <button className="w-full py-4 text-white bg-indigo-600 hover:bg-indigo-700 transition-colors text-xs font-bold uppercase tracking-widest">
                    Save Changes
                  </button>
                </div>
              </motion.div>
      
              {/* Logs Table */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
                className="lg:col-span-2 bg-[#050505] border border-white/10 overflow-hidden flex flex-col"
              >
                 <div className="p-6 border-b border-white/10 bg-white/5">
                  <h3 className="text-sm font-bold uppercase tracking-widest flex items-center gap-2">
                    Recent Interactions
                  </h3>
                 </div>
                 <div className="flex-1 overflow-x-auto">
                   <table className="w-full text-left text-sm">
                     <thead className="bg-[#050505] text-[10px] uppercase tracking-widest text-gray-500 border-b border-white/10">
                       <tr>
                         <th className="px-6 py-4 font-bold">Time</th>
                         <th className="px-6 py-4 font-bold">Student Interaction</th>
                         <th className="px-6 py-4 font-bold w-32">Status</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-white/5">
                       <tr className="hover:bg-white/5 transition-colors">
                         <td className="px-6 py-4 text-xs font-mono text-gray-400">Just now</td>
                         <td className="px-6 py-4 text-gray-300">Student ID 104 requested <span className="text-indigo-400 font-medium">Class 10 History Notes</span></td>
                         <td className="px-6 py-4"><span className="inline-flex items-center justify-center gap-1.5 px-2.5 py-1 bg-green-500/10 text-green-400 text-[10px] font-bold uppercase tracking-widest whitespace-nowrap"><CheckCircle2 className="w-3 h-3"/> Success</span></td>
                       </tr>
                       <tr className="hover:bg-white/5 transition-colors">
                         <td className="px-6 py-4 text-xs font-mono text-gray-400">2 mins ago</td>
                         <td className="px-6 py-4 text-gray-300">Student ID 492 triggered <span className="text-indigo-400 font-medium">Welcome Flow</span></td>
                         <td className="px-6 py-4"><span className="inline-flex items-center justify-center gap-1.5 px-2.5 py-1 bg-green-500/10 text-green-400 text-[10px] font-bold uppercase tracking-widest whitespace-nowrap"><CheckCircle2 className="w-3 h-3"/> Success</span></td>
                       </tr>
                       <tr className="hover:bg-white/5 transition-colors">
                         <td className="px-6 py-4 text-xs font-mono text-gray-400">15 mins ago</td>
                         <td className="px-6 py-4 text-gray-300">Student ID 218 requested <span className="text-indigo-400 font-medium">Class 12 Physics Mock</span></td>
                         <td className="px-6 py-4"><span className="inline-flex items-center justify-center gap-1.5 px-2.5 py-1 bg-green-500/10 text-green-400 text-[10px] font-bold uppercase tracking-widest whitespace-nowrap"><CheckCircle2 className="w-3 h-3"/> Success</span></td>
                       </tr>
                       <tr className="hover:bg-white/5 transition-colors text-gray-500">
                         <td className="px-6 py-4 text-xs font-mono text-gray-500">1 hr ago</td>
                         <td className="px-6 py-4">Student ID 881 submitted <span className="text-gray-400 font-medium">Support Query</span></td>
                         <td className="px-6 py-4"><span className="inline-flex items-center justify-center gap-1.5 px-2.5 py-1 bg-indigo-500/10 text-indigo-400 text-[10px] font-bold uppercase tracking-widest whitespace-nowrap">Routed</span></td>
                       </tr>
                     </tbody>
                   </table>
                 </div>
              </motion.div>
            </div>
          </div>
        );
      
      case 'dm_comments':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#050505] border border-white/10 overflow-hidden flex flex-col"
          >
            <div className="p-6 border-b border-white/10 bg-white/5 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold uppercase tracking-widest flex items-center gap-2">
                  DM from Comments
                </h3>
                <p className="text-xs text-gray-500 mt-1">Automatically send a DM when users comment specific keywords.</p>
              </div>
              <button 
                onClick={() => setIsAddingRule(true)}
                className="px-4 py-3 bg-indigo-600 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-700 transition-colors flex items-center gap-2"
              >
                <Plus className="w-3 h-3" /> Add New Trigger
              </button>
            </div>

            {/* Form */}
            <AnimatePresence>
              {isAddingRule && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="border-b border-white/10 bg-white/[0.02] overflow-hidden"
                >
                  <div className="p-6 md:p-8 space-y-8">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-xs font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2"><Plus className="w-4 h-4"/> Create New Rule</h4>
                      <button onClick={() => setIsAddingRule(false)} className="text-gray-500 hover:text-white transition-colors bg-white/10 p-2 rounded-full">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-3 flex items-center gap-2">
                          <Hash className="w-3 h-3" /> If User Comments Keyword
                        </label>
                        <input 
                          type="text" 
                          placeholder="e.g., Notes, History, Class10"
                          className="w-full bg-black/50 border border-white/10 px-4 py-4 text-xs focus:outline-none focus:border-indigo-500 transition-colors text-white placeholder:text-gray-700 shadow-inner"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-3 flex items-center gap-2">
                          <Filter className="w-3 h-3" /> Select Trigger Type
                        </label>
                        <select 
                          value={triggerType}
                          onChange={(e) => setTriggerType(e.target.value)}
                          className="w-full bg-black/50 border border-white/10 px-4 py-4 text-xs focus:outline-none focus:border-indigo-500 transition-colors text-white appearance-none [&>option]:bg-[#050505] [&>option]:text-white shadow-inner">
                          <option value="all">All Posts</option>
                          <option value="specific">Specific Reel/Post</option>
                        </select>
                      </div>

                      <AnimatePresence>
                        {triggerType === 'specific' && (
                          <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="md:col-span-2 overflow-hidden"
                          >
                            <div className="pt-2 pb-4">
                              <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-3 flex items-center gap-2">
                                <Instagram className="w-3 h-3" /> Select Post from @hotoopia.hs
                              </label>
                              {loadingPosts ? (
                                <div className="flex flex-col items-center justify-center p-12 border border-white/10 bg-black/50 gap-4 rounded-xl">
                                  <div className="w-8 h-8 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
                                  <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">Loading Latest Posts...</span>
                                </div>
                              ) : (
                                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                                  {igPosts.slice(0, 4).map(post => {
                                    const isReel = post.media_type === 'VIDEO';
                                    const bgImage = post.thumbnail_url || post.media_url;
                                    return (
                                      <button
                                        key={post.id}
                                        onClick={() => setSelectedPostId(post.id)}
                                        className={`relative aspect-[4/5] bg-white/5 border transition-all overflow-hidden flex flex-col items-center justify-center p-4 group ${
                                          selectedPostId === post.id 
                                            ? 'border-indigo-500 bg-indigo-500/20' 
                                            : 'border-white/10 hover:border-white/30'
                                        }`}
                                      >
                                        {bgImage && (
                                          <div className="absolute inset-0 bg-black/60 z-0">
                                            <img src={bgImage} alt="" className="w-full h-full object-cover opacity-50 group-hover:opacity-30 transition-opacity" crossOrigin="anonymous" />
                                          </div>
                                        )}
                                        <div className="relative z-10 flex flex-col items-center">
                                          {isReel ? (
                                            <PlayCircle className="w-10 h-10 text-white/50 mb-3 group-hover:text-white transition-colors drop-shadow-md" />
                                          ) : (
                                            <ImageIcon className="w-10 h-10 text-white/50 mb-3 group-hover:text-white transition-colors drop-shadow-md" />
                                          )}
                                          <span className="text-[10px] font-bold uppercase tracking-widest text-white text-center line-clamp-2 drop-shadow-md">
                                            {post.caption ? post.caption.slice(0, 30) + '...' : 'Media Post'}
                                          </span>
                                        </div>
                                        {selectedPostId === post.id && (
                                          <div className="absolute top-3 right-3 w-6 h-6 bg-indigo-500 rounded-full flex items-center justify-center z-10 shadow-lg">
                                            <CheckCircle2 className="w-4 h-4 text-white" />
                                          </div>
                                        )}
                                      </button>
                                    );
                                  })}
                                  {igPosts.length === 0 && !loadingPosts && (
                                    <div className="col-span-full p-6 border border-white/10 bg-black/50 text-center text-[10px] font-bold uppercase tracking-widest text-gray-500 rounded-xl">
                                      No posts found.
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      <div className="md:col-span-2">
                        <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-3 flex items-center gap-2">
                          <MessageSquare className="w-3 h-3" /> Automated DM Response Text
                        </label>
                        <textarea 
                          rows={4}
                          placeholder="Type the message and include the drive link or WhatsApp link..."
                          className="w-full bg-black/50 border border-white/10 px-4 py-4 text-sm focus:outline-none focus:border-indigo-500 transition-colors text-white resize-none placeholder:text-gray-700 shadow-inner"
                        ></textarea>
                      </div>
                    </div>
                    <div className="flex justify-end gap-4 pt-4 border-t border-white/10">
                      <button 
                        onClick={() => setIsAddingRule(false)}
                        className="px-8 py-4 border border-white/20 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-white/5 transition-colors"
                      >
                        Cancel
                      </button>
                      <button 
                        onClick={() => {
                          // Dummy save action
                          setIsAddingRule(false);
                        }}
                        className="px-8 py-4 bg-indigo-600 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-500/20"
                      >
                        Save Rule
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex-1 overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#050505] text-[10px] uppercase tracking-widest text-gray-500 border-b border-white/10">
                  <tr>
                    <th className="px-6 py-5 font-bold">Keyword</th>
                    <th className="px-6 py-5 font-bold">Trigger Type</th>
                    <th className="px-6 py-5 font-bold">Automated DM Response</th>
                    <th className="px-6 py-5 font-bold w-32 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {rules.map((rule) => (
                    <tr key={rule.id} className="hover:bg-white/5 transition-colors group">
                      <td className="px-6 py-5 font-bold text-indigo-400 group-hover:text-indigo-300 transition-colors">"{rule.keyword}"</td>
                      <td className="px-6 py-5 text-[10px] uppercase font-bold tracking-widest text-gray-400">{rule.trigger}</td>
                      <td className="px-6 py-5 text-gray-300 text-sm">
                        <div className="max-w-md truncate">{rule.response}</div>
                      </td>
                      <td className="px-6 py-5 text-center">
                        <button 
                          onClick={() => {
                            const updated = rules.map(r => r.id === rule.id ? { ...r, active: !r.active } : r);
                            setRules(updated);
                          }}
                          className={`inline-flex items-center justify-center p-1 rounded-full transition-colors ${rule.active ? 'text-green-400' : 'text-gray-600'}`}
                          title={rule.active ? "Active" : "Inactive"}
                        >
                          {rule.active ? <ToggleRight className="w-8 h-8" /> : <ToggleLeft className="w-8 h-8" />}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        );

      case 'dm_stories':
      case 'dm_all':
      case 'dm_live':
      case 'dm_mentions':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-20 px-4 text-center border border-white/10 bg-white/5"
          >
            <div className="w-16 h-16 bg-white/5 flex items-center justify-center rounded-full mb-6 relative">
              <div className="absolute inset-0 border border-white/20 rounded-full animate-ping opacity-20"></div>
              <AllDmsIcon className="w-8 h-8 text-indigo-400" />
            </div>
            <h3 className="text-xl font-black uppercase tracking-tighter mb-2">Coming Soon</h3>
            <p className="text-gray-400 text-sm max-w-md">
              Configuration for this automation module will be available in the next platform update.
            </p>
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#050505] text-white font-sans selection:bg-indigo-500/30">
      
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar Navigation */}
      <motion.aside
        className={`fixed lg:static inset-y-0 left-0 w-72 bg-[#050505] border-r border-white/10 z-50 transform ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 transition-transform duration-300 ease-in-out flex flex-col`}
      >
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-8 h-8 bg-indigo-600 rotate-45 transform flex items-center justify-center shadow-lg shadow-indigo-600/20">
                <div className="w-3 h-3 bg-white -rotate-45" />
              </div>
            </div>
            <span className="text-xl font-black tracking-tighter uppercase italic">AutoGram</span>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden text-gray-500 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-6">
          <div className="px-4 mb-2">
            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500 px-4 mb-4">Automation Suites</p>
          </div>
          <nav className="space-y-1 px-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold uppercase tracking-widest transition-all ${
                  activeTab === item.id 
                    ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 shadow-inner' 
                    : 'text-gray-400 hover:text-white hover:bg-white/5 border border-transparent'
                }`}
              >
                <item.icon className="w-4 h-4" /> {item.label}
              </button>
            ))}
          </nav>

          <div className="mt-12 px-4 mb-2">
            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500 px-4 mb-4">System Settings</p>
          </div>
          <nav className="space-y-1 px-4">
             <button
                className="w-full flex items-center gap-3 px-4 py-3 text-xs font-bold uppercase tracking-widest text-gray-400 hover:text-white hover:bg-white/5 border border-transparent transition-all"
              >
                <Settings className="w-4 h-4" /> Global Config
              </button>
          </nav>
        </div>

        <div className="p-6 border-t border-white/10">
           <button 
             onClick={onBack}
             className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-white/5 hover:bg-red-500/10 hover:text-red-400 border border-white/10 transition-colors text-[10px] font-bold uppercase tracking-widest"
           >
             <LogOut className="w-3 h-3" /> Disconnect & Home
           </button>
        </div>
      </motion.aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-h-screen overflow-hidden relative">
        {/* Mobile Header Top Bar */}
        <div className="lg:hidden flex items-center justify-between p-6 border-b border-white/10 bg-[#050505] z-30">
          <button onClick={() => setIsSidebarOpen(true)} className="text-white hover:text-indigo-400 transition-colors">
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.8)]"></span>
            <span className="text-[10px] font-bold uppercase tracking-widest">Live</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 md:p-10 pb-20">
          {renderContent()}
        </div>
      </main>

    </div>
  );
}

