import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Dashboard from './components/Dashboard';
import {
  Instagram,
  MessageCircle,
  Zap,
  Users,
  BarChart3,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  Menu,
  X,
  Play,
  Mail
} from 'lucide-react';

export default function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [isTermsModalOpen, setIsTermsModalOpen] = useState(false);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoadingAuth, setIsLoadingAuth] = useState(false);
  const [currentView, setCurrentView] = useState<'landing' | 'dashboard'>('landing');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3000);
  };

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      // Validate origin is from AI Studio preview or localhost
      const origin = event.origin;
      if (!origin.endsWith('.run.app') && !origin.includes('localhost')) {
        return;
      }
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        setIsLoggedIn(true);
        setIsAuthModalOpen(false);
        setCurrentView('dashboard');
        showToast('Instagram account connected successfully!');
        setIsLoadingAuth(false);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const handleInstagramLogin = async () => {
    setIsLoadingAuth(true);
    try {
      const redirectUri = `${window.location.origin}/api/auth/callback`;
      const params = new URLSearchParams({ redirectUri });
      const response = await fetch(`/api/auth/facebook/url?${params}`);
      
      if (!response.ok) throw new Error('Failed to fetch auth URL');
      
      const { url } = await response.json();
      
      const authWindow = window.open(
        url,
        'oauth_popup',
        'width=600,height=700'
      );
      
      if (!authWindow) {
        showToast('Please allow popups for this site to connect your account.');
        setIsLoadingAuth(false);
      }
      // The loading state will be reset when the OAUTH_AUTH_SUCCESS message is received
    } catch (error) {
      console.error('OAuth error:', error);
      showToast('Failed to start authentication flow.');
      setIsLoadingAuth(false);
    }
  };

  const handleEmailLogin = () => {
    setIsLoadingAuth(true);
    setTimeout(() => {
      setIsLoadingAuth(false);
      setIsLoggedIn(true);
      setIsAuthModalOpen(false);
      setCurrentView('dashboard');
      showToast('Logged in successfully!');
    }, 1500);
  };

  if (currentView === 'dashboard') {
    return <Dashboard onBack={() => setCurrentView('landing')} />;
  }

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-indigo-500/30 font-sans">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-[#050505]/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-10 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="w-8 h-8 bg-indigo-600 flex items-center justify-center">
              <Instagram className="w-5 h-5 text-white" />
            </div>
            <span className="text-2xl font-black tracking-tighter uppercase">AutoGram.</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm font-medium uppercase tracking-widest text-gray-400 hover:text-white transition-colors">Features</a>
            <a href="#how-it-works" className="text-sm font-medium uppercase tracking-widest text-gray-400 hover:text-white transition-colors">How it Works</a>
            <a href="#access" className="text-sm font-medium uppercase tracking-widest text-gray-400 hover:text-white transition-colors">Access</a>
          </div>

          <div className="hidden md:flex items-center gap-4">
            {isLoggedIn ? (
              <button 
                onClick={() => setCurrentView('dashboard')}
                className="px-6 py-2 bg-indigo-600 text-white text-xs font-bold uppercase tracking-widest hover:bg-indigo-700 transition-all flex items-center gap-2"
              >
                Dashboard <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button 
                onClick={() => setIsAuthModalOpen(true)}
                className="px-6 py-2 bg-white text-black text-xs font-bold uppercase tracking-widest hover:bg-indigo-500 hover:text-white transition-all"
              >
                Get Started
              </button>
            )}
          </div>

          <button 
            className="md:hidden text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden bg-[#050505] border-b border-white/10 overflow-hidden"
            >
              <div className="flex flex-col px-10 py-6 space-y-6">
                <a href="#features" onClick={() => setIsMobileMenuOpen(false)} className="text-sm font-medium uppercase tracking-widest text-gray-400 hover:text-white transition-colors">Features</a>
                <a href="#how-it-works" onClick={() => setIsMobileMenuOpen(false)} className="text-sm font-medium uppercase tracking-widest text-gray-400 hover:text-white transition-colors">How it Works</a>
                <a href="#access" onClick={() => setIsMobileMenuOpen(false)} className="text-sm font-medium uppercase tracking-widest text-gray-400 hover:text-white transition-colors">Access</a>
                {isLoggedIn ? (
                  <button 
                    onClick={() => { setIsMobileMenuOpen(false); setCurrentView('dashboard'); }} 
                    className="w-full py-3 bg-indigo-600 text-white text-xs font-bold uppercase tracking-widest hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
                  >
                    Dashboard <ArrowRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button 
                    onClick={() => { setIsMobileMenuOpen(false); setIsAuthModalOpen(true); }} 
                    className="w-full py-3 bg-indigo-600 text-white text-xs font-bold uppercase tracking-widest hover:bg-indigo-700 transition-colors"
                  >
                    Get Started
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-indigo-600/20 blur-[120px] rounded-full pointer-events-none opacity-50" />
        
        <div className="max-w-7xl mx-auto px-10 relative z-10">
          <div className="max-w-4xl mx-auto text-left flex flex-col items-start">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex items-center space-x-4 mb-4"
            >
              <span className="h-[1px] w-12 bg-indigo-500"></span>
              <p className="text-indigo-400 text-xs font-bold uppercase tracking-[0.3em]">Meta Approved Partner</p>
            </motion.div>

            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-5xl md:text-[110px] leading-[0.85] font-black tracking-tighter mb-8 uppercase"
            >
              AUTOMATE DMs.<br />
              <span className="text-transparent stroke-white" style={{ WebkitTextStroke: "1.5px white" }}>MULTIPLY SALES.</span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-gray-400 text-lg leading-relaxed mb-8 max-w-2xl"
            >
              Transform your Direct Messages into a high-conversion sales engine. AutoGram triggers personalized conversations, captures leads from comments, and manages your inbox 24/7.
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center gap-4 w-full"
            >
              {isLoggedIn ? (
                <button 
                  onClick={() => setCurrentView('dashboard')}
                  className="w-full sm:w-auto px-10 py-4 bg-indigo-600 text-white text-sm font-bold uppercase tracking-widest hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
                >
                  Go to Dashboard <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              ) : (
                <button 
                  onClick={() => setIsAuthModalOpen(true)}
                  className="w-full sm:w-auto px-10 py-4 bg-indigo-600 text-white text-sm font-bold uppercase tracking-widest hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
                >
                  Start Automating <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              )}
              <button 
                onClick={() => setIsVideoModalOpen(true)}
                className="w-full sm:w-auto px-10 py-4 border border-white/20 text-white text-sm font-bold uppercase tracking-widest hover:bg-white/5 transition-colors flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 mr-2" /> Watch Demo
              </button>
            </motion.div>
          </div>

          {/* Abstract Dashboard Graphic */}
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="mt-20 relative mx-auto max-w-5xl"
          >
            <div className="aspect-video bg-white/5 border border-white/10 overflow-hidden backdrop-blur-sm p-4 md:p-6 shadow-2xl relative">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-white/5 to-transparent pointer-events-none" />
              
              {/* Fake UI Header */}
              <div className="flex items-center gap-3 border-b border-white/10 pb-4 mb-4">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 bg-white/20" />
                  <div className="w-3 h-3 bg-white/20" />
                  <div className="w-3 h-3 bg-white/20" />
                </div>
                <div className="px-4 py-1.5 bg-white/5 text-xs font-mono text-gray-400 border border-white/5 uppercase tracking-widest">
                  autogram.io/dashboard/funnels
                </div>
              </div>

              {/* Fake UI Content */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full">
                <div className="md:col-span-1 space-y-4">
                  <div className="h-20 bg-white/5 border border-white/10 p-4 flex items-center gap-4">
                    <div className="w-10 h-10 bg-indigo-500/20 flex items-center justify-center">
                      <MessageCircle className="text-indigo-400 w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-[10px] uppercase font-bold tracking-widest text-gray-500">New DMs</div>
                      <div className="text-xl font-black">+1,248</div>
                    </div>
                  </div>
                  <div className="h-64 bg-white/5 border border-white/10 p-4 flex flex-col gap-3">
                    <div className="text-[10px] uppercase font-bold tracking-widest text-gray-500 mb-2">Active Triggers</div>
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-white/5 border border-white/5">
                        <div className="flex items-center gap-3">
                          <Zap className="w-4 h-4 text-indigo-400" />
                          <span className="text-xs font-medium tracking-wide">Comment on "GIVEAWAY"</span>
                        </div>
                        <div className="w-8 h-4 bg-indigo-500/20 flex items-center p-0.5">
                          <div className="w-3 h-3 bg-indigo-400 translate-x-4" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="md:col-span-2 bg-[#050505] border border-white/10 relative overflow-hidden flex flex-col">
                   <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/5">
                     <span className="text-xs font-bold uppercase tracking-wider">Visual Flow Builder</span>
                     <button 
                       onClick={() => showToast('Flow successfully published and active!')}
                       className="px-3 py-1 bg-indigo-600 text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-700 transition-colors"
                     >
                       Publish Flow
                     </button>
                   </div>
                   <div className="flex-1 p-6 flex flex-col items-center justify-center opacity-70 relative">
                     {/* Flow nodes simulation */}
                      <div className="w-48 p-3 bg-white/5 text-center text-xs border border-white/10 mb-6 relative">
                        User sends keyword "LINK"
                        <div className="absolute bottom-[-24px] left-1/2 w-[1px] h-6 bg-white/20"></div>
                        <div className="absolute bottom-[-24px] left-1/2 w-2 h-2 bg-white border border-[#050505] -translate-x-1/2 translate-y-2"></div>
                      </div>
                      <div className="w-64 p-3 bg-white/5 text-xs border border-white/10 flex items-start gap-3">
                        <div className="mt-1"><MessageCircle className="w-4 h-4 text-indigo-400" /></div>
                        <div className="text-left">
                          <span className="text-gray-500 text-[10px] font-bold uppercase tracking-wider block mb-1">Reply Message</span>
                          "Hey! Thanks for reaching out. Here is the link you requested: biu.link/offer"
                        </div>
                      </div>
                   </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Showcase */}
      <section id="features" className="py-24 relative bg-[#050505] border-y border-white/10">
        <div className="max-w-7xl mx-auto px-10">
          <div className="mb-16">
            <div className="flex items-center space-x-4 mb-4">
              <span className="h-[1px] w-8 bg-indigo-500"></span>
              <p className="text-indigo-400 text-xs font-bold uppercase tracking-[0.3em]">Features</p>
            </div>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase mb-4">Premium Automation Suite</h2>
            <p className="text-gray-400 text-lg max-w-2xl">Everything you need to scale your Instagram presence without lifting a finger.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 border-l border-t border-white/10">
            {features.map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="p-8 bg-white/5 border-r border-b border-white/10 group hover:bg-white/10 transition-colors"
              >
                <div className="text-indigo-500 font-bold mb-4 font-mono text-sm tracking-widest">
                  0{i + 1}
                </div>
                <h3 className="text-sm font-bold uppercase tracking-wider mb-2">{feature.title}</h3>
                <p className="text-xs text-gray-400 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Unlimited Access */}
      <section id="access" className="py-24">
        <div className="max-w-7xl mx-auto px-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase mb-4">No Subscriptions.<br/>Unlimited Power.</h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">We don't believe in paywalls or credit limits. Grow your audience without friction.</p>
          </div>

          <div className="max-w-5xl mx-auto bg-indigo-600 p-10 md:p-16 border border-indigo-500 relative shadow-2xl">
            <div className="absolute top-0 right-0 bg-white text-black px-4 py-2 text-xs font-bold uppercase tracking-widest">
              Forever Free
            </div>
            <div className="flex flex-col md:flex-row gap-12 items-center">
              <div className="flex-1">
                <h3 className="text-2xl font-black uppercase tracking-wider mb-2 text-white">Unlimited Plan</h3>
                <div className="mb-6">
                  <span className="text-7xl font-black text-white">$0</span>
                  <span className="text-sm ml-2 font-bold uppercase tracking-widest text-indigo-200">/ forever</span>
                </div>
                <p className="text-sm leading-relaxed mb-8 pb-8 border-b border-indigo-400 text-indigo-100">
                  Get full access to all premium features, unlimited automated messages, and advanced CRM tools at zero cost.
                </p>
                {isLoggedIn ? (
                  <button 
                    onClick={() => setCurrentView('dashboard')}
                    className="w-full py-4 text-xs font-bold uppercase tracking-widest transition-all bg-white text-indigo-600 hover:bg-gray-100 focus:outline-none"
                  >
                    Go to Dashboard
                  </button>
                ) : (
                  <button 
                    onClick={() => setIsAuthModalOpen(true)}
                    className="w-full py-4 text-xs font-bold uppercase tracking-widest transition-all bg-white text-indigo-600 hover:bg-gray-100 focus:outline-none"
                  >
                    Create Free Account
                  </button>
                )}
              </div>
              <div className="flex-1 w-full">
                <ul className="space-y-5">
                  {[
                    "Unlimited automated messages",
                    "Unlimited Visual Flow Builders",
                    "All smart keyword triggers",
                    "AI Response Generation",
                    "Unified Smart Inbox CRM",
                    "Advanced Analytics & Insights"
                  ].map((f, idx) => (
                    <li key={idx} className="flex items-center gap-4">
                      <CheckCircle2 className="w-5 h-5 shrink-0 text-white" />
                      <span className="text-sm font-bold uppercase tracking-wider text-white">{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer CTA & Footer */}
      <footer className="relative border-t border-white/10 bg-[#050505] pt-32 overflow-hidden">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-indigo-600/20 blur-[120px] rounded-full pointer-events-none opacity-50" />
        
        <div className="max-w-4xl mx-auto px-10 text-center mb-32 relative z-10">
          <h2 className="text-5xl md:text-[80px] leading-[0.9] font-black tracking-tighter uppercase mb-8">
            Ready for <br />
            <span className="text-transparent stroke-white" style={{ WebkitTextStroke: "1px white" }}>Autopilot?</span>
          </h2>
          <p className="text-lg text-gray-400 mb-8 font-medium">Join 10,000+ creators and brands saving 20+ hours a week.</p>
          {isLoggedIn ? (
            <button 
              onClick={() => setCurrentView('dashboard')}
              className="px-10 py-4 bg-indigo-600 text-white text-xs font-bold uppercase tracking-widest hover:bg-indigo-700 transition-colors inline-flex items-center justify-center gap-2"
            >
              Go to Dashboard <ArrowRight className="w-4 h-4 ml-2" />
            </button>
          ) : (
            <button 
              onClick={() => setIsAuthModalOpen(true)}
              className="px-10 py-4 bg-indigo-600 text-white text-xs font-bold uppercase tracking-widest hover:bg-indigo-700 transition-colors inline-flex items-center justify-center gap-2"
            >
              Get Started for Free <ArrowRight className="w-4 h-4 ml-2" />
            </button>
          )}
        </div>

        <div className="border-t border-white/10 py-10 relative z-10 bg-[#050505]">
          <div className="max-w-7xl mx-auto px-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-indigo-600 flex items-center justify-center">
                <Instagram className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-black tracking-tighter uppercase">AutoGram.</span>
            </div>
            
            <div className="text-[10px] uppercase tracking-widest text-gray-500 font-bold text-center">
              © {new Date().getFullYear()} AutoGram. Not affiliated with Instagram.
            </div>

            <div className="flex gap-8 text-[10px] font-bold uppercase tracking-widest text-gray-500">
              <button onClick={() => setIsTermsModalOpen(true)} className="hover:text-white transition-colors cursor-pointer">Terms</button>
              <button onClick={() => setIsPrivacyModalOpen(true)} className="hover:text-white transition-colors cursor-pointer">Privacy</button>
              <button onClick={() => setIsContactModalOpen(true)} className="hover:text-white transition-colors cursor-pointer">Contact</button>
            </div>
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      <AnimatePresence>
        {isAuthModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-[#050505] border border-white/10 p-8 shadow-2xl relative"
            >
              <button 
                onClick={() => setIsAuthModalOpen(false)}
                className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="text-center mb-8">
                <div className="w-12 h-12 bg-indigo-600 flex items-center justify-center mx-auto mb-4">
                  <Instagram className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-black uppercase tracking-tighter mb-2">Connect Account</h3>
                <p className="text-sm text-gray-400">Link your Instagram account to start automating.</p>
              </div>

              <div className="space-y-4">
                <button 
                  onClick={handleInstagramLogin}
                  disabled={isLoadingAuth}
                  className="w-full py-4 border border-white/20 bg-white/5 hover:bg-white/10 transition-colors flex items-center justify-center gap-3 text-sm font-bold uppercase tracking-widest disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoadingAuth ? (
                    <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Instagram className="w-5 h-5" />
                  )}
                  {isLoadingAuth ? 'Connecting...' : 'Continue with Instagram'}
                </button>
                <div className="relative py-4 flex items-center justify-center">
                  <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/10"></div></div>
                  <span className="relative bg-[#050505] px-4 text-xs font-bold uppercase tracking-widest text-gray-500">OR</span>
                </div>
                <button 
                  onClick={handleEmailLogin}
                  disabled={isLoadingAuth}
                  className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 transition-colors flex items-center justify-center gap-3 text-sm font-bold text-white uppercase tracking-widest disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoadingAuth ? (
                    <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Mail className="w-5 h-5" />
                  )}
                  {isLoadingAuth ? 'Logging in...' : 'Sign up with Email'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Video Modal */}
      <AnimatePresence>
        {isVideoModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4"
          >
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              className="w-full max-w-4xl bg-[#050505] border border-white/10 shadow-2xl aspect-video flex items-center justify-center relative"
            >
              <button 
                onClick={() => setIsVideoModalOpen(false)}
                className="absolute -top-12 right-0 text-white hover:text-indigo-400 transition-colors"
                title="Close"
              >
                <X className="w-8 h-8" />
              </button>
              
              <div className="text-center text-gray-500">
                <Play className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p className="font-bold uppercase tracking-widest">Demo Video Placeholder</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 20, x: '-50%' }}
            className="fixed bottom-8 left-1/2 z-[110] bg-indigo-600 text-white px-6 py-3 text-xs font-bold uppercase tracking-widest shadow-2xl border border-indigo-500 flex items-center gap-3 whitespace-nowrap"
          >
            <CheckCircle2 className="w-4 h-4" />
            {toastMessage}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Terms Modal */}
      <AnimatePresence>
        {isTermsModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-2xl bg-[#050505] border border-white/10 p-8 md:p-12 shadow-2xl relative max-h-[80vh] overflow-y-auto"
            >
              <button 
                onClick={() => setIsTermsModalOpen(false)}
                className="absolute top-6 right-6 text-gray-500 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <h3 className="text-3xl font-black uppercase tracking-tighter mb-8 italic">Terms of Service</h3>
              <div className="space-y-6 text-sm text-gray-400 leading-relaxed">
                <p>By using AutoGram, you agree to these terms. AutoGram provides automation tools for Instagram focused on DM and comment management.</p>
                <h4 className="text-white font-bold uppercase tracking-widest text-xs">1. Usage Responsibility</h4>
                <p>Users are solely responsible for the content of their automated messages and compliance with Instagram's community guidelines. AutoGram is not liable for account suspensions resulting from misuse of automation features.</p>
                <h4 className="text-white font-bold uppercase tracking-widest text-xs">2. API Connections</h4>
                <p>We use official Meta APIs. You must maintain valid authorization to keep your automations running.</p>
                <h4 className="text-white font-bold uppercase tracking-widest text-xs">3. Free Access</h4>
                <p>The "Unlimited" plan is provided as-is. We reserve the right to modify features or introduce rate limits to protect our infrastructure.</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Privacy Modal */}
      <AnimatePresence>
        {isPrivacyModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-2xl bg-[#050505] border border-white/10 p-8 md:p-12 shadow-2xl relative max-h-[80vh] overflow-y-auto"
            >
              <button 
                onClick={() => setIsPrivacyModalOpen(false)}
                className="absolute top-6 right-6 text-gray-500 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <h3 className="text-3xl font-black uppercase tracking-tighter mb-8 italic">Privacy Policy</h3>
              <div className="space-y-6 text-sm text-gray-400 leading-relaxed">
                <p>Your privacy is paramount. This policy describes how AutoGram handles your data.</p>
                <h4 className="text-white font-bold uppercase tracking-widest text-xs">1. Data Collection</h4>
                <p>We collect your Instagram User ID and Page Access Tokens only to facilitate DM automation. We do not store the content of your DMs unless you use our Smart Inbox features.</p>
                <h4 className="text-white font-bold uppercase tracking-widest text-xs">2. Third-Party Access</h4>
                <p>We never sell your data. Data is only shared with Meta (via their official APIs) as required to perform your requested automations.</p>
                <h4 className="text-white font-bold uppercase tracking-widest text-xs">3. Data Retention</h4>
                <p>You can disconnect your account and request data deletion at any time via your dashboard settings.</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Contact Modal */}
      <AnimatePresence>
        {isContactModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-[#050505] border border-white/10 p-8 shadow-2xl relative focus-within:border-indigo-500/50 transition-colors"
            >
              <button 
                onClick={() => setIsContactModalOpen(false)}
                className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="text-center mb-8">
                <div className="w-12 h-12 bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-6 h-6 text-indigo-400" />
                </div>
                <h3 className="text-2xl font-black uppercase tracking-tighter mb-2">Get in Touch</h3>
                <p className="text-sm text-gray-400">Questions? Feedback? Our team is here to help.</p>
              </div>

              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  setIsContactModalOpen(false);
                  showToast('Message sent! We\'ll get back to you soon.');
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-gray-500 mb-1.5 ml-1">Your Email</label>
                  <input 
                    type="email" 
                    required 
                    placeholder="name@example.com"
                    className="w-full bg-white/5 border border-white/10 px-4 py-3 text-sm focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-gray-700"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-gray-500 mb-1.5 ml-1">Message</label>
                  <textarea 
                    required 
                    rows={4}
                    placeholder="How can we help you?"
                    className="w-full bg-white/5 border border-white/10 px-4 py-3 text-sm focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-gray-700 resize-none"
                  ></textarea>
                </div>
                <button 
                  type="submit"
                  className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 transition-colors flex items-center justify-center gap-3 text-sm font-bold text-white uppercase tracking-widest mt-2"
                >
                  Send Message <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

const features = [
  {
    icon: <MessageCircle className="w-6 h-6 text-pink-400" />,
    title: "Comment to DM",
    description: "Automatically slide into the DMs of anyone who comments on your posts or reels with a specific keyword. Perfect for lead magnets."
  },
  {
    icon: <Zap className="w-6 h-6 text-yellow-400" />,
    title: "Keyword Triggers",
    description: "Set up smart auto-replies. When someone DMs you a specific word (like 'LINK'), instantly send them your funnel link or offer."
  },
  {
    icon: <Instagram className="w-6 h-6 text-purple-400" />,
    title: "Story Mentions",
    description: "Turn advocates into customers. Send an automated thank you message, discount code, or link whenever someone tags you in their story."
  },
  {
    icon: <Users className="w-6 h-6 text-blue-400" />,
    title: "Smart Inbox/CRM",
    description: "Manage thousands of conversations effortlessly. Tag leads, add notes, and filter DMs by funnel stage in our unified inbox."
  },
  {
    icon: <BarChart3 className="w-6 h-6 text-green-400" />,
    title: "Advanced Analytics",
    description: "Track open rates, click-through rates, and conversion metrics for all your automated flows to optimize your strategy."
  },
  {
    icon: <Sparkles className="w-6 h-6 text-orange-400" />,
    title: "AI Response Generation",
    description: "Let our AI analyze context and suggest personalized replies to complex inquiries that fall outside your automated paths."
  }
];

