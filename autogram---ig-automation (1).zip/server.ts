import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware to parse JSON bodies
  app.use(express.json());

  // === Instagram Webhook Routes ===
  
  // GET: Meta verification challenge
  app.get("/api/webhook", (req, res) => {
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];

    // Check if the verify token matches what we set in environment variables
    const verifyToken = process.env.VERIFY_TOKEN;

    if (mode && token) {
      if (mode === "subscribe" && token === verifyToken) {
        console.log("WEBHOOK_VERIFIED");
        res.status(200).type('text/plain').send(challenge);
      } else {
        // Responds with '403 Forbidden' if verify tokens do not match
        res.sendStatus(403);
      }
    } else {
      res.sendStatus(400);
    }
  });

  // POST: Receive incoming Instagram DM payloads
  app.post("/api/webhook", async (req, res) => {
    const body = req.body;

    // Return a '200 OK' response to all requests early to acknowledge receipt
    res.status(200).send("EVENT_RECEIVED");

    if (body.object === "instagram" || body.object === "page") {
      try {
        for (const entry of body.entry || []) {
          for (const messaging of entry.messaging || []) {
            if (messaging && messaging.message && !messaging.message.is_echo) {
              const senderId = messaging.sender.id;
              const messageText = messaging.message.text;

              if (messageText) {
                console.log(`Received message from ${senderId}: ${messageText}`);

                // Initialize Gemini
                if (!process.env.GEMINI_API_KEY) {
                  console.error("GEMINI_API_KEY environment variable is required");
                  continue;
                }
                const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
                
                // Call Gemini
                let replyText = "Sorry, I couldn't process your request.";
                try {
                  const response = await ai.models.generateContent({
                    model: "gemini-2.5-flash",
                    contents: messageText,
                    config: {
                      systemInstruction: "Act as a helpful assistant for the Hotoopia online e-learning platform, specifically guiding 8th to 12th-class students across all boards to the right study materials and courses.",
                    }
                  });
                  replyText = response.text || replyText;
                } catch (error) {
                  console.error("Gemini API Error:", error);
                }

                // Send via Meta Graph API
                const pageAccessToken = process.env.PAGE_ACCESS_TOKEN;
                if (!pageAccessToken) {
                  console.error("Missing PAGE_ACCESS_TOKEN environment variable.");
                  continue;
                }

                const apiVersion = "v21.0";
                const url = `https://graph.instagram.com/${apiVersion}/me/messages?access_token=${pageAccessToken}`;
                
                const graphResponse = await fetch(url, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    recipient: { id: senderId },
                    message: { text: replyText },
                  }),
                });

                if (!graphResponse.ok) {
                  console.error("Error sending message to Meta Graph API:");
                  console.error(await graphResponse.text());
                } else {
                  console.log("Successfully replied to Instagram DM.");
                }
              }
            }
          }
        }
      } catch (error) {
        console.error("Error processing webhook event:", error);
      }
    }
  });

  // === Auth Routes for Meta / Instagram App Login ===
  app.get("/api/auth/facebook/url", (req, res) => {
    // Construct the Facebook OAuth provider URL
    const redirectUri = (req.query.redirectUri as string) || "http://localhost:3000/api/auth/callback";
    const params = new URLSearchParams({
      client_id: process.env.META_APP_ID || "",
      redirect_uri: redirectUri,
      response_type: "code",
      scope: "instagram_basic,instagram_manage_messages,pages_show_list,pages_manage_metadata,pages_messaging",
    });

    const url = `https://www.facebook.com/v21.0/dialog/oauth?${params}`;
    res.json({ url });
  });

  app.get("/api/auth/callback", async (req, res) => {
    // In a real app, you would exchange req.query.code for an access token here.
    // For this demonstration, we'll post a success message back to the parent iframe/window.
    res.send(`
      <html>
        <body>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS' }, '*');
              window.close();
            } else {
              window.location.href = '/';
            }
          </script>
          <p>Authentication successful. You can close this window now.</p>
        </body>
      </html>
    `);
  });

  // Fetch Instagram Posts
  app.get("/api/instagram/posts", async (req, res) => {
    try {
      const pageAccessToken = process.env.PAGE_ACCESS_TOKEN;
      if (!pageAccessToken) {
        return res.status(500).json({ error: "Missing PAGE_ACCESS_TOKEN" });
      }

      if (pageAccessToken.startsWith("IG")) {
        // Use Instagram Graph API directly for direct Instagram tokens
        const mediaRes = await fetch(`https://graph.instagram.com/v21.0/me/media?fields=id,caption,media_type,media_url,thumbnail_url,permalink&limit=8&access_token=${pageAccessToken}`);
        if (!mediaRes.ok) {
          const err = await mediaRes.text();
          console.error("Failed to fetch IG media directly:", err);
          return res.status(mediaRes.status).json({ error: "Failed to fetch Instagram media" });
        }

        const mediaData = await mediaRes.json();
        return res.json({ posts: mediaData.data });
      }

      // Step 1: Get the connected Instagram Business Account ID
      const pageRes = await fetch(`https://graph.facebook.com/v21.0/me?fields=instagram_business_account&access_token=${pageAccessToken}`);
      if (!pageRes.ok) {
        const err = await pageRes.text();
        console.error("Failed to fetch page info:", err);
        return res.status(pageRes.status).json({ error: "Failed to fetch page info" });
      }
      
      const pageData = await pageRes.json();
      const igAccountId = pageData.instagram_business_account?.id;

      if (!igAccountId) {
        return res.status(404).json({ error: "No Instagram Business Account linked." });
      }

      // Step 2: Fetch media from the Instagram Account
      const mediaRes = await fetch(`https://graph.facebook.com/v21.0/${igAccountId}/media?fields=id,caption,media_type,media_url,thumbnail_url,permalink&limit=8&access_token=${pageAccessToken}`);
      if (!mediaRes.ok) {
        const err = await mediaRes.text();
        console.error("Failed to fetch IG media:", err);
        return res.status(mediaRes.status).json({ error: "Failed to fetch Instagram media" });
      }

      const mediaData = await mediaRes.json();
      res.json({ posts: mediaData.data });
    } catch (error) {
      console.error("Error fetching IG posts:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // API Health Check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Static serving for production
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // SPA fallback
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
